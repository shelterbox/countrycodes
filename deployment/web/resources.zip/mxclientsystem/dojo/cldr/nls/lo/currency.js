define(
//begin v1.x content
{
	"HKD_displayName": "ດອນລາ ຮົງກົງ",
	"CHF_displayName": "ຟຣັງ ສະວິດເຊີແລນ",
	"JPY_symbol": "JP¥",
	"CAD_displayName": "ໂດລ່າຄານາດາ",
	"HKD_symbol": "HK$",
	"CNY_displayName": "ຢວນ ຈີນ",
	"USD_symbol": "US$",
	"AUD_displayName": "ໂດລາ ອອດສະເຕເລຍ",
	"JPY_displayName": "ເຢນ ຍີ່ປຸ່ນ",
	"CAD_symbol": "CA$",
	"USD_displayName": "ໂດລ່າ ສະຫະລັດຯ",
	"EUR_symbol": "€",
	"CNY_symbol": "CN¥",
	"GBP_displayName": "ປອນສະເຕີຣິງ (ອັງກິດ)",
	"GBP_symbol": "£",
	"AUD_symbol": "A$",
	"EUR_displayName": "ເອີໂຣ"
}
//end v1.x content
);