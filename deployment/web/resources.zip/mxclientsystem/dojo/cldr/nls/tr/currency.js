/*
	Copyright (c) 2004-2016, The JS Foundation All Rights Reserved.
	Available via Academic Free License >= 2.1 OR the modified BSD license.
	see: http://dojotoolkit.org/license for details
*/

//>>built
define("dojo/cldr/nls/tr/currency",{HKD_displayName:"Hong Kong Dolar\u0131",CHF_displayName:"\u0130svi\u00e7re Frang\u0131",JPY_symbol:"\u00a5",CAD_displayName:"Kanada Dolar\u0131",HKD_symbol:"HK$",CNY_displayName:"\u00c7in Yuan\u0131",USD_symbol:"$",AUD_displayName:"Avustralya Dolar\u0131",JPY_displayName:"Japon Yeni",CAD_symbol:"CA$",USD_displayName:"ABD Dolar\u0131",EUR_symbol:"\u20ac",CNY_symbol:"CN\u00a5",GBP_displayName:"\u0130ngiliz Sterlini",GBP_symbol:"\u00a3",AUD_symbol:"AU$",EUR_displayName:"Euro"});
