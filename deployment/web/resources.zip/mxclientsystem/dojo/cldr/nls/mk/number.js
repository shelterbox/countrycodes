/*
	Copyright (c) 2004-2016, The JS Foundation All Rights Reserved.
	Available via Academic Free License >= 2.1 OR the modified BSD license.
	see: http://dojotoolkit.org/license for details
*/

//>>built
define("dojo/cldr/nls/mk/number",{group:".",percentSign:"%",exponential:"E",scientificFormat:"#E0",percentFormat:"#,##0%",list:";",infinity:"\u221e",minusSign:"-",decimal:",",superscriptingExponent:"\u00d7",nan:"NaN",perMille:"\u2030",decimalFormat:"#,##0.###",currencyFormat:"\u00a4\u00a0#,##0.00",plusSign:"+","decimalFormat-long":"000 \u0442\u0440\u0438\u043b\u0438\u043e\u043d\u0438","decimalFormat-short":"000\u00a0\u0442\u0440\u0438\u043b'.'"});
