/*
	Copyright (c) 2004-2016, The JS Foundation All Rights Reserved.
	Available via Academic Free License >= 2.1 OR the modified BSD license.
	see: http://dojotoolkit.org/license for details
*/

//>>built
define("dojo/cldr/nls/zh-hant/currency",{HKD_displayName:"\u6e2f\u5e63",CHF_displayName:"\u745e\u58eb\u6cd5\u90ce",JPY_symbol:"\u00a5",CAD_displayName:"\u52a0\u5e63",HKD_symbol:"HK$",CNY_displayName:"\u4eba\u6c11\u5e63",USD_symbol:"$",AUD_displayName:"\u6fb3\u5e63",JPY_displayName:"\u65e5\u5713",CAD_symbol:"CA$",USD_displayName:"\u7f8e\u5143",EUR_symbol:"\u20ac",CNY_symbol:"CN\u00a5",GBP_displayName:"\u82f1\u938a",GBP_symbol:"\u00a3",AUD_symbol:"AU$",EUR_displayName:"\u6b50\u5143"});
