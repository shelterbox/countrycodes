/*
	Copyright (c) 2004-2016, The JS Foundation All Rights Reserved.
	Available via Academic Free License >= 2.1 OR the modified BSD license.
	see: http://dojotoolkit.org/license for details
*/

//>>built
define("dojo/cldr/nls/id/roc",{"field-sat-relative+0":"Sabtu ini","field-sat-relative+1":"Sabtu berikutnya","field-dayperiod":"AM/PM","field-sun-relative+-1":"Minggu lalu","field-mon-relative+-1":"Senin lalu","field-minute":"Menit","dateFormatItem-MMMEd":"E, d MMM","field-day-relative+-1":"kemarin","field-weekday":"Hari dalam Seminggu","field-day-relative+-2":"kemarin lusa","dateFormatItem-MMM":"LLL","field-era":"Era","field-hour":"Jam","dateFormatItem-y":"G y","field-sun-relative+0":"Minggu ini",
"field-sun-relative+1":"Minggu berikutnya","field-wed-relative+-1":"Rabu lalu","field-day-relative+0":"hari ini","field-day-relative+1":"besok",eraAbbr:["Sebelum R.O.C.","R.O.C."],"field-day-relative+2":"lusa","dateFormat-long":"d MMMM y G","field-tue-relative+0":"Selasa ini","field-zone":"Zona Waktu","field-tue-relative+1":"Selasa berikutnya","field-week-relative+-1":"minggu lalu","dateFormat-medium":"d MMM y G","field-year-relative+0":"tahun ini","field-year-relative+1":"tahun depan","field-sat-relative+-1":"Sabtu lalu",
"field-year-relative+-1":"tahun lalu","field-year":"Tahun","field-fri-relative+0":"Jumat ini","field-fri-relative+1":"Jumat berikutnya","field-week":"Minggu","dateFormatItem-MMMMEd":"E, d MMMM","dateFormatItem-MMMd":"d MMM","field-week-relative+0":"minggu ini","field-week-relative+1":"Minggu berikutnya","field-month-relative+0":"bulan ini","field-month":"Bulan","field-month-relative+1":"Bulan berikutnya","field-fri-relative+-1":"Jumat lalu","dateFormatItem-MMMMd":"d MMMM","dateFormatItem-M":"L","field-second":"Detik",
"field-tue-relative+-1":"Selasa lalu","field-day":"Hari","dateFormatItem-MEd":"E, d/M","field-mon-relative+0":"Senin ini","field-mon-relative+1":"Senin berikutnya","field-thu-relative+0":"Kamis ini","field-second-relative+0":"sekarang","dateFormat-short":"d/M/y GGGGG","field-thu-relative+1":"Kamis berikutnya","dateFormat-full":"EEEE, dd MMMM y G","dateFormatItem-Md":"d/M","field-wed-relative+0":"Rabu ini","field-wed-relative+1":"Rabu berikutnya","dateFormatItem-d":"d","field-month-relative+-1":"bulan lalu",
"field-thu-relative+-1":"Kamis lalu"});
