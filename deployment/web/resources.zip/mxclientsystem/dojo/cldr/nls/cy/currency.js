define(
//begin v1.x content
{
	"HKD_displayName": "Doler Hong Kong",
	"CHF_displayName": "Ffranc y Swistir",
	"JPY_symbol": "JP¥",
	"CAD_displayName": "Doler Canada",
	"HKD_symbol": "HK$",
	"CNY_displayName": "Yuan Tsieina",
	"USD_symbol": "US$",
	"AUD_displayName": "Doler Awstralia",
	"JPY_displayName": "Yen Japan",
	"CAD_symbol": "CA$",
	"USD_displayName": "Doler UDA",
	"EUR_symbol": "€",
	"CNY_symbol": "CN¥",
	"GBP_displayName": "Punt Sterling Prydain",
	"GBP_symbol": "£",
	"AUD_symbol": "A$",
	"EUR_displayName": "Ewro"
}
//end v1.x content
);